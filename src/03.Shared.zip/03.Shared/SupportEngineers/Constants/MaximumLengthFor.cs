﻿namespace Pertamina.SolutionTemplate.Shared.SupportEngineers.Constants;

public static class MaximumLengthFor
{
    public const int EmployeeId = 50;
}
