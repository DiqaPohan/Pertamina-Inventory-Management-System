﻿using Pertamina.SolutionTemplate.Shared.Common.Extensions;

namespace Pertamina.SolutionTemplate.Shared.SupportEngineers.Constants;

public static class DisplayTextFor
{
    public static readonly string SupportEngineer = nameof(SupportEngineer).SplitWords();
}
