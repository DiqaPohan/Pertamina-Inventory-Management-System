﻿using Pertamina.SolutionTemplate.Shared.Common.Responses;

namespace Pertamina.SolutionTemplate.Shared.Audits.Queries.ExportAudits;

public class ExportAuditsResponse : FileResponse
{
}
