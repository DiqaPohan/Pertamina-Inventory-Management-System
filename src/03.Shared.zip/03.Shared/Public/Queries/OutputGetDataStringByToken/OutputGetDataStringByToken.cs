﻿namespace Pertamina.SolutionTemplate.Shared.Public.Queries.OutputGetDataStringByToken;
public class OutputGetDataStringByTokenData
{
    public string? ResponseCode { get; set; }
    public string? ResponseMessage { get; set; }
    public string? Items { get; set; }
    public DateTime? Tanggal { get; set; }
}
