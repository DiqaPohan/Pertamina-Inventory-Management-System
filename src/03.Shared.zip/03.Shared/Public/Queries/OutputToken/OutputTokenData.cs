﻿namespace Pertamina.SolutionTemplate.Shared.Public.Queries.OutputToken;
public class OutputTokenData
{
    public string? ResponseCode { get; set; }
    public string? ResponseMessage { get; set; }
    public string? Items { get; set; }
    public DateTime? Tanggal { get; set; }
}
