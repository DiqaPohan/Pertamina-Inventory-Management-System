﻿namespace Pertamina.SolutionTemplate.Shared.Public.Queries.GetSingleDataApplicationType;
public class GetSingleDataApplicationType
{
    public string? Application_Type_ID { get; set; }
    public string? Application_Type_Desc { get; set; }
}
