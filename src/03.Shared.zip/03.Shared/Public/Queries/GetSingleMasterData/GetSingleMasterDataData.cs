﻿namespace Pertamina.SolutionTemplate.Shared.Public.Queries.GetSingleMasterData;
public class GetSingleMasterDataData
{
    public string? Table_Name { get; set; }
    public string? Id { get; set; }
    public string? Nama { get; set; }
    public string? Keterangan { get; set; }
}
