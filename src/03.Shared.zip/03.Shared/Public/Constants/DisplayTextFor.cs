﻿namespace Pertamina.SolutionTemplate.Shared.Public.Constants;
public static class DisplayTextFor
{
    public const string Public = nameof(Public);
}
