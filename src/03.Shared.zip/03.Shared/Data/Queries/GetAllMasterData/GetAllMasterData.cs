﻿
namespace Pertamina.SolutionTemplate.Shared.Data.Queries.GetAllMasterData;
public class GetAllMasterData
{
    public string? Table_Name { get; set; }
    public string? Id { get; set; }
    public string? Nama { get; set; }
    public string? Keterangan { get; set; }
}
