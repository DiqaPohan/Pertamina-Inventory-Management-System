﻿namespace Pertamina.SolutionTemplate.Shared.Data.Constants;
public static class MaximumLengthFor
{
    public const int Name = 100;
    public const int Description = 500;
}
