﻿using Pertamina.SolutionTemplate.Shared.Common.Responses;

namespace Pertamina.SolutionTemplate.Shared.Data.Commands.CreateData;
public class EditCatalogResponse : Response
{
    public string Code_App { get; init; }
}
