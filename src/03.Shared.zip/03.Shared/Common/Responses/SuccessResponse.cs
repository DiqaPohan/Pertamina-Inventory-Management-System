﻿namespace Pertamina.SolutionTemplate.Shared.Common.Responses;

public class SuccessResponse : Response
{
}
