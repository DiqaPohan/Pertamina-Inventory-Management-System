﻿namespace Pertamina.SolutionTemplate.Shared.Common.Enums;

public enum SortOrder
{
    None = 0,
    Asc = 1,
    Desc = 2
}
