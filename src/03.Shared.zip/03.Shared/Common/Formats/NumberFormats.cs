﻿namespace Pertamina.SolutionTemplate.Shared.Common.Formats;

public static class NumberFormats
{
    public const string Currency0 = "C0";
    public const string Percentage0 = "P0";
}
