﻿namespace Pertamina.SolutionTemplate.Shared.Common.Constants;

public static class EnvironmentVariables
{
    public const string AspNetCoreEnvironment = "ASPNETCORE_ENVIRONMENT";
}
