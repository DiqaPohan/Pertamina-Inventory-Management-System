﻿namespace Pertamina.SolutionTemplate.Shared.Services.HealthCheck.Queries.GetHealthCheck;

public class GetHealthCheckHealthCheckEntry
{
    public string Status { get; set; } = default!;
}
