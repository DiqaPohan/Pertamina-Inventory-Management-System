﻿using Pertamina.SolutionTemplate.Shared.Common.Extensions;

namespace Pertamina.SolutionTemplate.Shared.Services.UserProfile.Constants;

public static class UserProfileDisplayTextFor
{
    public static readonly string UserProfileProvider = nameof(UserProfileProvider).SplitWords();
}
