﻿namespace Pertamina.SolutionTemplate.Shared.Services.Authentication.Constants;

public static class AuthenticationProvider
{
    public const string None = nameof(None);
    public const string IdAMan = nameof(IdAMan);
    public const string IS4IM = nameof(IS4IM);
}
