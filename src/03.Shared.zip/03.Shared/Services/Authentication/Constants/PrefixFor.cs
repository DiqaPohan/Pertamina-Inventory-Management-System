﻿namespace Pertamina.SolutionTemplate.Shared.Services.Authentication.Constants;

public static class PrefixFor
{
    public const string ApiScope = "api://";
}
