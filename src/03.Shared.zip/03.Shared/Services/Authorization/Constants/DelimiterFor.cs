﻿namespace Pertamina.SolutionTemplate.Shared.Services.Authorization.Constants;

public static class AuthorizationDelimiterFor
{
    public const char CustomParameter = '/';
}
