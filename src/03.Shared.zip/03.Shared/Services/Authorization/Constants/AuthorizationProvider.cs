﻿namespace Pertamina.SolutionTemplate.Shared.Services.Authorization.Constants;

public static class AuthorizationProvider
{
    public const string None = nameof(None);
    public const string IdAMan = nameof(IdAMan);
    public const string IS4IM = nameof(IS4IM);
}
