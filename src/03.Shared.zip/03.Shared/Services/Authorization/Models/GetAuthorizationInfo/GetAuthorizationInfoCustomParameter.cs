﻿namespace Pertamina.SolutionTemplate.Shared.Services.Authorization.Models.GetAuthorizationInfo;

public class GetAuthorizationInfoCustomParameter
{
    public string Key { get; set; } = default!;
    public string Value { get; set; } = default!;
}
